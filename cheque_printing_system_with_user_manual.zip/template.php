<html>
<head>
<?php
$img = $_GET['bg'];
echo "<style>
	body{
		background-image:url('templates/$img');
		background-repeat:no-repeat;
	}
	div{
		position:fixed;
	}
</style>";

?>
</head>
<body>
<?php
	require('connect.php');
	
	$bankId = $_GET['bank'];
	$amtPadding = '';
	//get template values
	$sql = mysqli_query($conn,"select * from banks where bank_id=$bankId");
	$template = mysqli_fetch_array($sql);
	for($i=0;$i<=$template['amt_padding']; $i++)
		$amtPadding .= '&nbsp;';
	echo '<div id="date" 
	style="top:'.$template['date_top'].'px; left:'.$template['date_left'].'px; width:'.$template['date_width'].'px">
	'.date('d/m/Y').'</div>
	<div id="payee" 
	style="top:'.$template['payee_top'].'px; left:'.$template['payee_left'].'px; width:'.$template['payee_width'].'px">
	xxxxxxx xxxxxx xxxxxx</div>
	<div id="amt_words" 
	style="top:'.$template['amt_top'].'px; left:'.$template['amt_left'].'px; width:'.$template['cont_width'].'px; line-height:'.$template['amt_line_height'].'">
	'.$amtPadding.'xxxxx xxxxxxxxx xxxxx xxxxx xxxxx xxxxx xxxxx xxxxx</div>
	<div id="amount" 
	style="top:'.$template['amount_top'].'px; left:'.$template['amount_left'].'px; width:'.$template['amount_width'].'px">
	xx,xxx.xx</div>
	';

?>


</body>
</html>