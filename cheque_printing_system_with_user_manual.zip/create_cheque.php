<?php
$token = $_GET['token'];
$getTot = mysqli_query($conn,"select sum(amt_allocated) as totalamt from allocation where token='$token'");
$result = mysqli_fetch_array($getTot);
$amt = $result['totalamt'];
//if only one allocation is made
$getDet = mysqli_query($conn,"select detail from allocation where token='$token'");
if(mysqli_num_rows($getDet)==1)
{
	$res = mysqli_fetch_array($getDet);
	$detail = $res['detail'];
}
elseif(mysqli_num_rows($getDet)>1)
	$detail = 'As Below:-';
else
	$detail = '';
echo '
<hr>
<div style="width:300px; margin:auto;">
<span style="color:red">'.@$msg.'</span>
<form method="post" autocomplete="off">
	<fieldset>
		<legend><h2 style="clear:both;margin:0">Create a cheque</h2></legend>
		<p>Payee<br>
		<input type="text" name="payee" list="payees" autofocus="autofocus" required></p>
		<p>Currency &nbsp;
		<select name="currency" style="height:30px; width:100px;" id="curr">
			<option value="KSHS.">KSHS.</option>
			<option value="USD.">USD.</option>
		</select></p>
		<p>Allocation <a href="#" onclick="newAllocation('.$token.')">Add detail</a><br>
		<input type="text" name="reason" value="'.$detail.'" required></p>
		<p>Amount<br>
		<input type="number" step="any" name="amount" value="'.$amt.'" readonly required></p>	
		<p>Cheque Date<br>
		<input type="date" name="cheque_date" value="'.date('Y-m-d').'" required></p>	
		<input type="hidden" name="token" value="'.$token.'">
		<input type="submit" name="writeCheque" value="Write Cheque">
	</fieldset>
</form>
</div>
';
echo '<datalist id="payees">
';
$getPayees = mysqli_query($conn,"select distinct payee from cheques order by payee");
while($r=mysqli_fetch_array($getPayees))
{
	echo '<option value="'.$r['payee'].'">';
}
echo '
</datalist>';
?>