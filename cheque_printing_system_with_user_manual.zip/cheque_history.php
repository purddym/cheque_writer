	<?php
	if(isset($_POST['chequeNo']))
		{
			$no = $_POST['chequeNo'];
			$id = $_POST['cheque'];
			$upd = mysqli_query($conn,"update cheque_print set cheque_num=$no where cheque=$id");
			if(! $upd)
				echo mysqli_error($conn);
			else
				echo 'updated';
		}
		echo '
		<h1 align="center">Cheques history</h1>
		<div id="search">
		<form method="get">
			<fieldset>
				<legend>Search Vouchers by date</legend>
				<input type="hidden" name="history" value="search">
				From <input type="date" value="'.date('Y-m-d',time()-(7*3600*24)).'" name="from">
				To <input type="date" value="'.date('Y-m-d').'" name="to">
				<input type="submit" value="Search">
			</fieldset>
		</form>
		</div>
		<table width="800">
			<tr class="head">
				<td>No</td>
				<!--<td>Date Created</td>-->
				<td>Beneficiary</td>
				<td>Amount</td>
				<td>Cheque Date</td>
				<td>Printed</td>
				<td>Cheque #</td>
				<td>Voucher</td>
				<td>Reprint Cheque</td>
				<td>&nbsp;</td>
			</tr>
		';
		$no = 1;
		if($_GET['history']=='search')
		{
			if(isset($_GET['from'],$_GET['to']))
			{
				$start = verify($_GET['from']);
				$end = verify($_GET['to']);
				if($utype === 'admin')
					$sql = mysqli_query($conn,"select * from allocation, cheques
							left join cheque_print on cheque_id=cheque_print.cheque
							where cheque_date >= '$start' and cheque_date <= '$end'
							and allocation.cheque=cheque_id
							order by cheque_id desc");
				else
					$sql = mysqli_query($conn,"select * from allocation, cheques
							left join cheque_print on cheque_id=cheque_print.cheque
							where cheque_date >= '$start' and cheque_date <= '$end'
							and created_by = $user
							and allocation.cheque=cheque_id
							order by cheque_id desc");
			}
		}
		else
		{
			$sql = mysqli_query($conn,"select * from allocation, cheques
							left join cheque_print on cheque_id=cheque_print.cheque
							where created_by = $user
							and allocation.cheque=cheque_id
							order by cheque_id desc");
		}
		
		while($r = mysqli_fetch_array($sql))
		{
			if($r['print_status']==0)
				$printed = 'No';
			else
				$printed = 'Yes';
			$chequeNo = $r['cheque_num'];
			//$chequeNo = $r['cheque_id'];
			if($chequeNo == NULL)
			{
				$chequeNo = '
				<form method="post" style="padding:0; margin:0;">
					<input type="hidden" name="cheque" value="'.$r['cheque_id'].'">
					<input type="number" name="chequeNo" placeholder="Cheque#" onchange="submit()" style="width:70px; margin:0; height:20px; padding:5px;">
				</form>
				';
				if($printed == 'No')
				{
					$chequeNo = 'None';
					$chklink = 'Not printed';
				}
				else
					$chklink = '<a href="?print&chequeID='.$r['cheque_id'].'&bankID='.$r['bank'].'">RePrint</p>';
				$link = 'Add cheque#';
			}
			else
			{
				$chequeNo = str_pad($chequeNo,6,0,STR_PAD_LEFT);
				//$chequeNo = '<a href="#" onclick="conf('."'".$chequeNo."','".$r['cheque_id']."'".')" title="click to edit">'.$chequeNo.'</a>';
				$chequeNo = '<a href="#" onclick="conf('.$r['cheque_id'].')" title="click to edit">'.$chequeNo.'</a>';
				$link = '<a href="?voucher&cheque='.$r['cheque_id'].'">Print</p>';
				$chklink = '<a href="?print&chequeID='.$r['cheque_id'].'&bankID='.$r['bank'].'">RePrint</p>';
			}
			echo '
			<tr>
				<td align="right">'.$no++.'.</td>
				<!-- <td>'.$r['created_on'].'</td> -->
				<td>'.$r['payee'].'</td>
				<td align="right">'.number_format($r['amount'],2).'</td>
				<td>'.date('d/m/Y',strtotime($r['cheque_date'])).'</td>
				<td>'.$printed.'</td>
				<td>'.$chequeNo.'</td>
				<td>'.$link.'</td>
				<td>'.$chklink.'</td>
				<td><a href="?edit_cheque&id='.$r['cheque_id'].'&token='.$r['token'].'">Edit</a></td>
			</tr>
			';
		}
		echo '
		</table>
		';
	?>
	<script>
	function conf(chkId){
		if(confirm("Are you sure you want to delete cheque number?")){
			document.location="deletechqno.php?id="+chkId;
		}
		else
			alert("Cheque number will not be deleted");
	}
	</script>