<?php
include 'connect.php';
if(isset($_SERVER['HTTP_REFERER']) && isset($_GET['al']))
{
	$al = $_GET['al'];
	$del = mysqli_query($conn,"delete from allocation where allocation_id=$al");
	header('location: '.$_SERVER['HTTP_REFERER']);
}
else
	header('location: ./');
?>