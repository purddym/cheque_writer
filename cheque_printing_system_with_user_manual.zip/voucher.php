<?php
if(isset($_COOKIE['logged_in_user']) && isset($_GET['cheque']))
{
$user = $_COOKIE['logged_in_user'];
include 'connect.php';
include 'fxns.php';
$chequeID = verify($_GET['cheque']);
$get = mysqli_query($conn,"select * from cheques, cheque_print, banks
where cheque_id=cheque and cheque_id=$chequeID and bank_id=bank");
$r=mysqli_fetch_array($get);
$bank = $r['bank_name'];
$date = date('d/m/Y',strtotime($r['cheque_date']));
//remove some characters for acronym of bank name
$bankE = str_ireplace(' of ',' ',$bank);
$bankE = str_ireplace(' and ',' ',$bankE);
$vn = substr($bankE,0,1);
$num = substr_count($bankE,' ');
$sp = 0;
for($i=1; $i<=$num; $i++)
{
	$sp = strpos($bankE,' ',$sp+1)+1;
	$vn .= substr($bankE,$sp,1);
}
$vno = strtoupper($vn).str_pad($r['print_id'],3,0,STR_PAD_LEFT);
?>
<html>
	<head>
		<title>Cheque Voucher</title>
		<style>
			body{
				font-family: Book Antiqua;
			}
			table, td{
				border-collapse:collapse;
			}
			.detail{
				font-size:14px;
			}
		</style>
	</head>
	<body>
		<div id="head" style="text-align:center">
			<h1 style="display:inline; margin-bottom:0;">Venus Tea Brokers Ltd</h1>  
			<p style="position:absolute; right:10px; top:0; text-align:right;"><?php echo date('d/m/Y') ?></span>
			<p style="margin-top:0;">Email: info@venustea.com<br>
			P.O. Box 99954<br>
			MOMBASA, KENYA</p>
			<p>&nbsp;</p>
			<p><strong>CHEQUE PAYMENT VOUCHER</strong><br>
			"SUPPLIER'S A/C"</p>
			<p style="position:absolute; right:10px; top:155px; text-align:right;">Voucher No.:  <?php echo str_pad($vno,10,' ',STR_PAD_LEFT) ?><br>
			Date: <?php echo str_pad($date,10,'&nbsp;',STR_PAD_LEFT) ?></p>
		</div>
		<table>
			<tr style="height:30">
				<td><strong>Bank:</strong></td><td><u><?php echo $bank; ?></u></td>
			</tr>
			<tr style="height:30">
				<td><strong>Payee:</strong></td><td><u><?php echo $r['payee']; ?></u></td>
			</tr>
			<tr style="height:30">
				<td><strong>Allocation:</strong></td><td><u><?php echo $r['reason']; ?></u></td>
			</tr>
		</table>
		<p>&nbsp;</p>
		<table width="100%">
			<tr>
				<th style="border-bottom:solid 1px; border-top:solid 1px;" width="30">No.</th>
				<th style="border-bottom:solid 1px; border-top:solid 1px; border-right:solid 1px;" width="500">Details</th>
				<th style="border-bottom:solid 1px; border-top:solid 1px;" width="80"><?php echo $r['currency']; ?></th>
			</tr>
			<?php
			$no = 1;
			$getallocation = mysqli_query($conn,"select * from allocation where cheque=$chequeID");
			$num = mysqli_num_rows($getallocation);
			while($ro = mysqli_fetch_array($getallocation))
			{
				if($no==$num)
					$style = 'border-bottom:solid 1px;';
				else
					$style = '';
				echo '
			<tr style="height:30" class="detail">
				<td style="'.$style.'" align="right">'.$no++.'.</td>
				<td style="border-right:solid 1px; padding-left:5px; '.$style.'">'.$ro['detail'].'</td>
				<td style="'.$style.' padding-right:20px; text-align:right;">'.number_format($ro['amt_allocated'],2).'</td>
			</tr>
				';
			}
			?>
			<tr class="detail">
				<td style="border-bottom:solid 1px; border-left:solid 1px;">&nbsp;</td>
				<td style="border-bottom:solid 1px; border-right:solid 1px;">Cheque Number: <?php echo str_pad($r['cheque_num'],6,0,STR_PAD_LEFT); ?>
				<span style="float:right">Totals</span>&nbsp;&nbsp;&nbsp; </td>
				<td style="border-bottom:solid 1px; border-right:solid 1px; font-weight:bold; padding-right:20px; text-align:right;"><?php echo number_format($r['amount'],2) ?></td>
			</tr>
		</table>
		<p>&nbsp;</p>
		<table width="100%">
			<tr>
				<td width="120">Prepared by</td><td width="150" style="border-bottom:solid 1px;">&nbsp;</td>
				<td>&nbsp;</td>
				<td width="120">Checked by</td><td width="150" style="border-bottom:solid 1px;">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="5">&nbsp;</td>
			</tr>
			<tr>
				<td width="120">Authorised by</td><td width="150" style="border-bottom:solid 1px;">&nbsp;</td>
				<td>&nbsp;</td>
				<td width="120">&nbsp;</td><td width="150">&nbsp;</td>
			</tr>
		</table>
	</body>
</html>
<?php
}
else
	echo '<h1 align="center" style="margin-top:200px">404: Unauthorised Access!</h1>';
?>