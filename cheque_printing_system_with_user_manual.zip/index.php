<?php
require('connect.php');
require('fxns.php');
?>
<html>
	<head>
		<title>Check Printer</title>
	<style type="text/css">
		#header{
			position:fixed;
			bottom:0;
			left:0;
			width:99%;
			margin:0;
			font-size:10pt;
			color:#333;
		}
		#header a{
			color:#222;
			text-decoration:none;
		}
		input{
			width:300px;
			height:30px;
			padding:5px;
		}
		input:hover{
			background-color:#f60;
		}
		#templateEdit p{
			width:150px;
			margin-top:0;
			padding:20px;
			padding-top:0;
			float:left;
			display:inline;
			line-height:40px;
			vertical-align:top;
		}
		#templateEdit p input{
			float:right;
			clear:both;
			width:60px;
			height:30px;
			padding:5px;
		}
		#templateEdit p:hover{
			background-color:#EE9;
		}
		ul{
			list-style-type:none;
		}
		.li{
			padding:10px;
			width:200px;
			display:inline;
			background-color:#eee;
			float:left;
			margin:5px;
			text-align:center;
			min-height:230px;
		}
		.li:hover{
			background-color:#0f4;
			border-radius:5px;
		}
		table{
			border:solid 1px;
			border-collapse:collapse;
			margin:auto;
		}
		tr{
			vertical-align:top;
		}
		tr:hover{
			background-color:#eee;
		}
		td{
			border-right:solid 1px;
			border-collapse:collapse;
			padding:5px;/**/
			margin:0;
		}
		.head{
			background-color:#ddd;
		}
		.head td{
			border-bottom:solid 1px;
		}
		.admin{
			display:none;
		}
		a{
			color:#06f;
			text-decoration:none;
		}
		#search{
			width:800px;
			max-width:100%;
			margin:auto;
		}
		#search input{
			width:150px;
			max-width:100%;
		}
		.org{
			text-align:center;
		}
		.org h1{
			font-size: 30pt;
		}
	</style>
	<script>
	function iPrint(ptarget){
		ptarget.focus();
		ptarget.print();
	}
	function chequePrint(ptarget,bank,cId){
		ptarget.focus();
		ptarget.print();
		document.location="mark_cheque.php?bank="+bank+"&cheque="+cId;
	}
	</script>
		<script src="jquery.min.js"></script>
	</head>
	<body>
	<div id="header">
		Cheque Printing System
		<span style="float:right;">
		<?PHP
		if(isset($_GET['ERR']))
			echo '<script>alert("Incorrect username/password");document.location="./"</script>';
		if(isset($_COOKIE['logged_in_user']))
			echo '<a href="#passResetError" onClick="changePass()">Change Password</a> | <a href="logout.php">Logout</a>';
		?>
		</span>
	</div>

<?php
//include login screen
if(! isset($_COOKIE['logged_in_user']))
{
	//login page
	?>
	<div class="org">
		<h1>Venus Tea Brokers Ltd.</h1>
		<h2>Cheque Printing System</h2>
		<hr>
	</div>
	<div id="login" class="default">
		<form method="post" action="userlogin.php" style="width:330px; margin:auto; margin-top:30px; margin-botton:30px;">
			<fieldset>
				<legend style="text-align:center;"><h2 style="margin:0;">Staff Login</h2></legend>
				<p>Username<br>
				<input type="text" name="username" autofocus="autofocus" required></p>
				<p>Password<br>
				<input type="password" name="passwd" required></p>
				<input type="submit" name="adminLogin" value="Login">
			</fieldset>
		</form>
	</div>
	<?php
}
else
{
	//after authenication
	$user = $_COOKIE['logged_in_user'];
	$utype = $_COOKIE['utype'];
	?>
		<div id="passReset" class="admin">
		<form method="post" action="" style="width:330px; margin:auto; margin-top:30px; margin-botton:30px;">
			<fieldset>
				<legend><h2 style="margin:0;">Change password</h2></legend>
				<p>Old Password<br>
				<input type="password" id="oldPass" name="oldPass" autofocus="autofocus" required></p>
				<p>New Password<br>
				<input type="password" id="newPass" name="newPass" autofocus="autofocus" required></p>
				<p>Confirm Password<br>
				<input type="password" id="confirmPass" name="confirmPass" onkeyup="checkPass()" required></p>
				<input type="submit" name="passwordReset" id="btn" value="Reset password">
			</fieldset>
		</form>
		<?php
		if(isset($_POST['passwordReset']))
		{
			$oldP = sha1($_POST['oldPass']);
			$newP = sha1($_POST['newPass']);
			$chk = mysqli_query($conn,"select * from users where user_id=$user and password='$oldP'");
			if(mysqli_num_rows($chk)==1)
			{
				$upd = mysqli_query($conn,"update users set password='$newP' where user_id=$user");
				if($upd)
					echo '<script>alert("Password reset successful")</script>';
				else
					echo '<script>document.location="./?passResetError";alert("Unable to reset your password")</script>';
			}
			else
				echo '<script>document.location="./?passResetError";alert("Wrong password provided")</script>';
		}
		?>
		<script>
			<?php
			if(isset($_GET['passResetError']))
				echo 'changePass();';
			?>
			function changePass(){
				$('#passReset').toggle();
				$('#content').toggle();
			}/**/
			function checkPass(){
				var newPass = document.getElementById('newPass').value;
				var confirmPass = document.getElementById('confirmPass').value;
				if(confirmPass == newPass){
					document.getElementById('btn').disabled = false;
					document.getElementById('btn').value = 'Change Password';
				}
				else{
					document.getElementById('btn').disabled = true;
					document.getElementById('btn').value = 'Passwords mismatch';
				}
			}
		</script>
	</div>
	<?php
	//add bank
	if($utype == 'admin')
	{
		if(isset($_POST['add_bank']))
		{
			$bankName = verify($_POST['bankName']);
			$bg = $_FILES['bgImg']['name'];
			$chk = mysqli_query($conn,"select * from banks where bank_name='$bankName'");
			if(mysqli_num_rows($chk)==0)//proceed
			{
				$ins = mysqli_query($conn,"insert into banks set bank_name='$bankName'");
				$bankId = mysqli_insert_id($conn);
				$ext = pathinfo($bg,PATHINFO_EXTENSION);
				$bgname = $bankName.'.'.$ext;
				$bgpath = 'templates/'.$bgname;
				if(move_uploaded_file($_FILES['bgImg']['tmp_name'],$bgpath))
				{
					$insT = mysqli_query($conn,"insert into templates set bank=$bankId, bg_img='$bgname'");
					if($insT)
						$bMsg = $_POST['bankName'].' has been added';
				}
				else
				{
					$undo = mysqli_query($conn,"delete from banks where bank_id=$bankId");
					if($undo)
						$bMsg = 'Unable to upload image!';
				}
			}
			else
				$bMsg = 'Bank already added';
		}
		//edit templates
		if(isset($_GET['bank']))
		{
			$bankId = $_GET['bank'];
			//edit dimensions
			if(isset($_POST['dimensions']))
			{
				$width = $_POST['width'];
				$height = $_POST['height'];
				$upd = mysqli_query($conn,"update templates set width='$width', height='$height' 
				where bank=$bankId");
				$fields = array('payee_top','payee_left','payee_width','cont_width','amt_top','amt_left','amt_padding','amount_top','amount_left','amount_width','date_top','date_left','date_width','amt_line_height');
				foreach($fields as $field)
				{
					$upd = mysqli_query($conn,"update banks set $field = ".$_POST[$field]." where bank_id=$bankId");
				}
			}
			$sql = mysqli_query($conn,"select * from banks where bank_id=$bankId");
			$template = mysqli_fetch_array($sql);
			//get template area and background
			$sql = mysqli_query($conn,"select * from templates where bank=$bankId");
			$bank = mysqli_fetch_array($sql);
			//dimensions
			echo '<div align="center" id="templateEdit">
			<form method="post">
				<p>Dimansions:<br>
					<input type="hidden" name="dimensions" value="set">
					Width: <input type="number" step="5" value="'.$bank['width'].'" name="width" onchange="submit()"> <br>
					Height: <input type="number" step="5" value="'.$bank['height'].'" name="height" onchange="submit()">
				</p>
				<p>Date Field:<br>
					Top: <input type="number" step="5" value="'.$template['date_top'].'" name="date_top" onchange="submit()"> <br>
					Left: <input type="number" step="5" value="'.$template['date_left'].'" name="date_left" onchange="submit()"><br>
					Width: <input type="number" step="5" value="'.$template['date_width'].'" name="date_width" onchange="submit()">
				</p>
				<p>Payee Field:<br>
					Top: <input type="number" step="5" value="'.$template['payee_top'].'" name="payee_top" onchange="submit()"> <br>
					Left: <input type="number" step="5" value="'.$template['payee_left'].'" name="payee_left" onchange="submit()"><br>
					Width: <input type="number" step="5" value="'.$template['payee_width'].'" name="payee_width" onchange="submit()"> 
				</p>
				<p>Amount in words:<br>
					Top: <input type="number" step="5" value="'.$template['amt_top'].'" name="amt_top" onchange="submit()"><br> 
					Left: <input type="number" step="5" value="'.$template['amt_left'].'" name="amt_left" onchange="submit()"><br>
					Width: <input type="number" step="5" value="'.$template['cont_width'].'" name="cont_width" onchange="submit()"><br> 
					Text offset: <input type="number" step="5" value="'.$template['amt_padding'].'" name="amt_padding" onchange="submit()"><br> 
					Line height: <input type="number" step="5" value="'.$template['amt_line_height'].'" name="amt_line_height" onchange="submit()"> 
				</p>
				<p>Amount Field:<br>
					Top: <input type="number" step="5" value="'.$template['amount_top'].'" name="amount_top" onchange="submit()"><br> 
					Left: <input type="number" step="5" value="'.$template['amount_left'].'" name="amount_left" onchange="submit()"><br>
					Width: <input type="number" step="any" value="'.$template['amount_width'].'" name="amount_width" onchange="submit()"> 
				</p>
			</form>
			<form method="get">
				<p>Select Bank to adjust Check 
				<select name="bank">
					';
					$sql = mysqli_query($conn,"select bank_id, bank_name from banks order by bank_name");
					while($r=mysqli_fetch_array($sql))
					{
						echo '<option value="'.$r['bank_id'].'">'.$r['bank_name'].'</option>
						';
					}
				echo '</select>
				<input type="submit" style="width:100%" value="Select Bank"></p>
			</form>
			</div>
			<h5 style="clear:both; margin:0;">Preview <span style="float:right"><a href="?"><button>Finish editing</button></a></h5>
			<hr>';
			//display the template design
			echo '<div align="center" style="clear:both;"><iframe src="template.php?bank='.$bankId.'&bg='.$bank['bg_img'].'" style="width:'.$bank['width'].'px; height:'.$bank['height'].';"></div>';
		}
	}
	//create or edit a cheque
	include 'cheque_manager.php';
	if($utype === 'admin')
	{
		$bgcolor = '';
		$width = 1150;
	}
	else
	{
		$bgcolor = ' style="display:none;"';
		$width = 690;
	}
	echo '<div style="width:'.$width.'px;max-width:100%;padding:0;margin:auto;" id="content">
	<div class="li"'.$bgcolor.'>
		<h3>Add Banks</h3>
		<span style="color:red">'.@$bMsg.'</span>
		<form method="post" enctype="multipart/form-data">
			<strong>Add Bank to database</strong><br>
			<input type="text" name="bankName" style="width:100%"><br><br>
			<input type="file" name="bgImg" style="width:100%;"><br><br>
			<input type="submit" style="width:100%;" name="add_bank" value="Add Bank">
		</form>
	</div>
	<div class="li"'.$bgcolor.'>
	<h3>Edit Templates</h3><br>
	<form method="get">
		<strong>Select Bank to adjust Cheque </strong><br><br>
		<select name="bank" style="width:100%; height:30px;">
			';
			$sql = mysqli_query($conn,"select bank_id, bank_name from banks order by bank_name");
			while($r=mysqli_fetch_array($sql))
			{
				echo '<option value="'.$r['bank_id'].'">'.$r['bank_name'].'</option>
				';
			}
		$tok = time().rand(100,999);
		echo '</select><br><br>
		<input type="submit" style="width:100%;" value="Select Bank">
	</form>
	</div>
	<div class="li">
		<h3>Create a cheque</h3><br>
		<a href="?create&token='.$tok.'"><button style="height:115px; width:200px;">Create Cheque</button></a>
	</div>
	<div class="li">
		<h3>Print cheques</h3>
		<form method="get">
			<input type="hidden" name="print">
			<strong>Select Bank to print cheque</strong><br>
			<select name="chequeID" style="width:100%; height:30px;" required>
				';
				$sql = mysqli_query($conn,"select * from cheques where print_status=0 order by payee");
				while($r=mysqli_fetch_array($sql))
				{
					echo '<option value="'.$r['cheque_id'].'">'.$r['currency'].' '.$r['amount'].' for '.$r['payee'].'</option>
					';
				}
			echo '</select><br><br>
			<select name="bankID" style="width:100%; height:30px;">
				';
				$sql = mysqli_query($conn,"select bank_id, bank_name from banks order by bank_name");
				while($r=mysqli_fetch_array($sql))
				{
					echo '<option value="'.$r['bank_id'].'">'.$r['bank_name'].'</option>
					';
				}
			echo '</select><br><br>
			<input type="submit" style="width:100%;" value="Preview Cheque">
		</form>
	</div>
	<div class="li">
		<h3>View cheque history</h3><br>
		<a href="?history"><button style="height:115px; width:200px;">Past Cheques</button></a>
	</div>
	</div>
	<hr style="clear:both;">
	';
	if(isset($_GET['create']))
	{
		include 'create_cheque.php';
	}
	if(isset($_GET['edit_cheque']))
	{
		include 'edit_cheque.php';
	}
	elseif(isset($_GET['print']))
	{
		$cheque_id = verify($_GET['chequeID']);
		$bank_id = verify($_GET['bankID']);
		
		//get template area and background
		$sql = mysqli_query($conn,"select * from templates where bank=$bank_id");
		$bank = mysqli_fetch_array($sql);
		echo '
		<h5 style="clear:both; margin:0;">Preview <span style="float:right">
		<button onClick="chequePrint(cheque,'.$bank_id.','.$cheque_id.')">Print</button></h5>
		<hr>
		';
		//display the cheque design
		echo '
		<div align="center" style="clear:both;">
		<iframe name="cheque" src="print.php?bank='.$bank_id.'&cheque='.$cheque_id.'&bg='.$bank['bg_img'].'" style="width:'.$bank['width'].'px; height:'.$bank['height'].';"></div>
		';
	}
	elseif(isset($_GET['voucher']))
	{
		$cheque_id = verify($_GET['cheque']);
		//print button
		echo '
		<h5 style="clear:both; margin:0;">Preview <span style="float:right">
		<button onClick="iPrint(cheque)">Print</button></h5>
		<hr>
		';
		//display the voucher design
		echo '
		<div align="center" style="clear:both;">
		<iframe name="cheque" src="voucher.php?cheque='.$cheque_id.'" style="width:680px; height:400px;"></div>
		';
	}
	elseif(isset($_GET['history']))
	{
		include 'cheque_history.php';
	}
}
?>
<script>
	function newAllocation(token){
		var curr = document.getElementById('curr').value;
		window.open("addDetail.php?token="+token+"&curr="+curr,"addDetail","toolbar=no,location=no,menubar=no,height=400, width=500, top=100, left=400");
	}
</script>
</body>
</html>