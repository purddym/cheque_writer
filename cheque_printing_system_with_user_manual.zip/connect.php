<?php
$conn = mysqli_connect('localhost','root','','cheque_writer');
?>