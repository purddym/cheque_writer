<!Doctype html>
<html>
	<head>
		<title>Cheque allocation</title>
	</head>
	<body>
		<form method="post" style="width:300px; margin:auto;">
		<?php
		include 'connect.php';
		include 'fxns.php';
		$token = $_GET['token'];
		$currency = $_GET['curr'];
		if(isset($_POST['add']))
		{
			$detail = verify($_POST['detail']);
			$amt = verify($_POST['amt']);
			$chk = mysqli_query($conn,"select * from allocation where token='$token' and detail='$detail'");
			if(mysqli_num_rows($chk)==0)
			{
				$ins = mysqli_query($conn,"insert into allocation set detail='$detail', amt_allocated='$amt', token='$token'");
				if($ins)
					echo '<script>alert("New record added")</script>';
				else
					echo '<script>alert("An error occurred while saving.\nCheck the characters used\n"+"'.mysqli_error($conn).'")</script>';
			}
			else
				echo '<script>alert("Record already added")</script>';
		}
		$getTot = mysqli_query($conn,"select sum(amt_allocated) as totalamt from allocation where token='$token'");
		$result = mysqli_fetch_array($getTot);
		echo '
		<style>
		input {
			height:30px;
			width:100%;
			margin:0;
		}
		</style>
		<h2>Cheque Allocation</h2>
		<h3>Total: <span style="color:#f00">'.$currency.' '.number_format($result['totalamt'],2).'</span></h3>';
		?>
			<p>Payment breakdown<br>
			<input type="text" name="detail" autofocus="autofocus" required></p>
			<p>Amount<br>
			<input type="number" name="amt" step="any" min="1" max="99999999" required></p>
			<input type="submit" name="add" value="Add Detail">
		</form>
		<h3>Current Allocation:</h3>
		<?php
		$no = 1;
		echo '<table width="100%">
		<tr>
			<td>No.</td>
			<td>Detail</td>
			<td>Amount</td>
			<!--<td>&nbsp;</td>-->
			<td>&nbsp;</td>
		</tr>';
		$sql = mysqli_query($conn,"select * from allocation where token='$token' order by detail");
		while($r=mysqli_fetch_array($sql))
		{
			echo '<tr>
				<td>'.$no++.'</td>
				<td>'.$r['detail'].'</td>
				<td>'.$r['amt_allocated'].'</td>
				<!-- <td><a href="?edit&al='.$r['allocation_id'].'">Edit</a></td> -->
				<td><a href="delete.php?al='.$r['allocation_id'].'">Delete</a></td>
			</tr>';
		}
		?>
	</body>
</body>
<script>
    window.onunload = refreshParent;
    function refreshParent() {
        window.opener.location.reload();
    }
</script>