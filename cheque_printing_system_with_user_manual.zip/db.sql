-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2023 at 07:23 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Database: `cheque_writer`
--
DROP DATABASE IF EXISTS `cheque_writer`;
CREATE DATABASE IF NOT EXISTS `cheque_writer` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `cheque_writer`;

-- --------------------------------------------------------

--
-- Table structure for table `allocation`
--

CREATE TABLE `allocation` (
  `allocation_id` int(11) NOT NULL,
  `cheque` int(11) DEFAULT NULL,
  `detail` varchar(200) NOT NULL,
  `amt_allocated` decimal(10,2) NOT NULL,
  `token` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `allocation`
--

INSERT INTO `allocation` (`allocation_id`, `cheque`, `detail`, `amt_allocated`, `token`) VALUES
(15, 14, 'Hardware supplies', '1400000.00', '1527158358579'),
(16, 14, 'Software development', '1300000.00', '1527158358579'),
(17, 14, 'Installation and setup', '50000.00', '1527158358579'),
(18, 14, 'User training', '50000.00', '1527158358579'),
(19, 15, 'Text book supplies', '150000.00', '1527161004280'),
(20, 16, 'Labour', '25000.00', '1527163699326'),
(21, 16, 'Material', '78000.00', '1527163699326'),
(22, 17, 'Office supplies', '80000.00', '1527330854774'),
(23, 17, 'Hardware supplies', '45000.00', '1527330854774'),
(24, 18, 'Cheque printing software', '500.00', '1527766135205'),
(25, 19, 'Servicing of computers', '50000.00', '1527769590682'),
(26, 20, 'System development', '3300.00', '1680546842122'),
(27, 20, 'Maintenance', '350.00', '1680546842122'),
(28, 20, 'Training', '650.00', '1680546842122');

-- --------------------------------------------------------

--
-- Table structure for table `banks`
--

CREATE TABLE `banks` (
  `bank_id` int(11) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `payee_top` int(11) NOT NULL,
  `payee_left` int(11) NOT NULL,
  `payee_width` int(11) NOT NULL,
  `cont_width` int(11) NOT NULL,
  `amt_top` int(11) NOT NULL,
  `amt_left` int(11) NOT NULL,
  `amt_padding` int(11) NOT NULL,
  `amt_line_height` double NOT NULL,
  `amount_top` int(11) NOT NULL,
  `amount_left` int(11) NOT NULL,
  `amount_width` int(11) NOT NULL,
  `date_top` int(11) NOT NULL,
  `date_left` int(11) NOT NULL,
  `date_width` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `banks`
--

INSERT INTO `banks` (`bank_id`, `bank_name`, `payee_top`, `payee_left`, `payee_width`, `cont_width`, `amt_top`, `amt_left`, `amt_padding`, `amt_line_height`, `amount_top`, `amount_left`, `amount_width`, `date_top`, `date_left`, `date_width`) VALUES
(1, 'Commercial Bank of Africa', 150, 60, 300, 300, 175, 35, 18, 1.5, 133, 400, 50, 35, 400, 100),
(2, 'Stanbic Bank Kenya', 121, 35, 300, 300, 145, 20, 15, 1.7, 112, 360, 40, 15, 380, 100);

-- --------------------------------------------------------

--
-- Table structure for table `cheques`
--

CREATE TABLE `cheques` (
  `cheque_id` int(11) NOT NULL,
  `currency` varchar(5) NOT NULL,
  `payee` varchar(150) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `amt_in_words` varchar(200) NOT NULL,
  `reason` varchar(350) NOT NULL,
  `cheque_date` date NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `print_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cheques`
--

INSERT INTO `cheques` (`cheque_id`, `currency`, `payee`, `amount`, `amt_in_words`, `reason`, `cheque_date`, `created_by`, `created_on`, `print_status`) VALUES
(1, 'KSHS.', 'Emily Thorne', '148750.00', 'One hundred and forty-eight thousand, seven hundred and fifty', '', '2018-04-26', 1, '2018-04-26 10:27:19', 1),
(2, 'KSHS.', 'Purdym Enterprises Limited', '1300000.00', 'One million, three hundred thousand', '', '2018-04-30', 1, '2018-04-26 10:27:50', 1),
(3, 'KSHS.', 'Purdym Enterprises Limited', '123500.00', 'One hundred and twenty-three thousand, five hundred', 'Development of information management system', '2018-04-27', 1, '2018-04-26 12:01:29', 1),
(4, 'KSHS.', 'Annlab consultants', '2000000.00', 'Two million', 'Supply of Hp Server', '2018-04-27', 1, '2018-04-27 06:34:39', 1),
(5, 'KSHS.', 'Annlab consultants', '5000.00', 'Five thousand', 'servicing', '2018-05-09', 1, '2018-05-09 12:48:24', 1),
(6, 'KSHS.', 'Purdym Enterprises Limited', '15200.00', 'Fifteen thousand, two hundred', 'Systems updates', '2018-05-11', 1, '2018-05-10 06:37:24', 1),
(7, 'KSHS.', 'Eric Odhiambo', '182500.00', 'One hundred and eighty-two thousand, five hundred', 'Consultancy', '2018-05-10', 1, '2018-05-10 06:40:14', 1),
(8, 'KSHS.', 'Patrick Mutisya', '254125.00', 'Two hundred and fifty-four thousand, one hundred and twenty-five', 'Some reason', '2018-05-10', 1, '2018-05-10 06:43:13', 1),
(9, 'KSHS.', 'Yinda Mo', '150000.00', 'One hundred and fifty thousand', 'xxxx', '2018-05-16', 1, '2018-05-23 08:13:57', 1),
(10, 'KSHS.', 'Purdym Enterprises Limited', '1300000.00', 'One million, three hundred thousand', 'Information management system', '2018-05-24', 1, '2018-05-24 08:17:59', 1),
(14, 'KSHS.', 'Purdym Enterprises Limited', '2800000.00', 'Two million, eight hundred thousand', 'As Below:-', '2018-05-29', 1, '2018-05-24 10:53:18', 1),
(15, 'KSHS.', 'Jumeira Enterprises', '150000.00', 'One hundred and fifty thousand', 'Textbook supplies', '2018-05-31', 1, '2018-05-24 11:59:09', 1),
(16, 'KSHS.', 'Joysteve Limited', '103000.00', 'One hundred and three thousand', 'As Below:-', '2018-05-30', 1, '2018-05-24 12:10:38', 1),
(17, 'KSHS.', 'Erick Odhiambo', '125000.00', 'One hundred and twenty-five thousand', 'As Below:-', '2018-05-30', 1, '2018-05-26 10:47:31', 1),
(18, 'USD.', 'Purdym Enterprises Limited', '500.00', 'Five hundred', 'Software', '2018-05-31', 4, '2018-05-31 11:36:12', 1),
(19, 'KSHS.', 'Erick Odhiambo', '50000.00', 'Fifty thousand', 'As below:-', '2018-05-31', 4, '2018-05-31 12:29:02', 0),
(20, 'KSHS.', 'Patrick Mutisya', '4300.00', 'Four thousand, three hundred', 'As Below:-', '2023-04-03', 1, '2023-04-03 18:36:11', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cheque_print`
--

CREATE TABLE `cheque_print` (
  `print_id` int(11) NOT NULL,
  `cheque` int(11) NOT NULL,
  `bank` int(11) NOT NULL,
  `date_printed` timestamp NOT NULL DEFAULT current_timestamp(),
  `cheque_num` int(6) DEFAULT NULL,
  `no` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cheque_print`
--

INSERT INTO `cheque_print` (`print_id`, `cheque`, `bank`, `date_printed`, `cheque_num`, `no`) VALUES
(1, 1, 1, '2018-04-26 10:27:55', 147, 1),
(2, 2, 2, '2018-04-26 10:28:14', 123, 1),
(3, 3, 2, '2018-04-26 12:01:35', 169, 1),
(4, 4, 1, '2018-04-27 06:35:35', NULL, 1),
(5, 5, 1, '2018-05-09 13:08:23', NULL, 1),
(6, 6, 7, '2018-05-10 06:37:35', NULL, 1),
(7, 6, 1, '2018-05-10 06:37:52', NULL, 1),
(8, 7, 1, '2018-05-10 06:41:28', NULL, 1),
(9, 7, 6, '2018-05-10 06:41:38', NULL, 1),
(10, 8, 1, '2018-05-10 06:43:25', NULL, 1),
(11, 10, 1, '2018-05-24 08:34:49', 91452, 1),
(12, 9, 1, '2018-05-24 10:02:55', NULL, 1),
(13, 14, 1, '2018-05-24 10:57:04', 9856, 1),
(14, 15, 1, '2018-05-24 11:59:17', 9857, 1),
(15, 17, 1, '2018-05-26 10:47:36', 9875, 1),
(16, 16, 1, '2018-05-31 11:01:04', NULL, 1),
(17, 18, 1, '2018-05-31 12:56:55', 3340, 1);

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE `templates` (
  `template_id` int(11) NOT NULL,
  `bank` int(11) NOT NULL,
  `bg_img` varchar(50) NOT NULL,
  `width` double NOT NULL,
  `height` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `templates`
--

INSERT INTO `templates` (`template_id`, `bank`, `bg_img`, `width`, `height`) VALUES
(1, 1, 'cba.png', 540, 305),
(2, 2, 'stanbic.png', 500, 280),
(4, 6, 'Equity Bankjpg', 600, 400),
(5, 7, 'KCBjpg', 690, 330),
(6, 10, 'Soneri Bank.jpg', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `usertype`, `status`) VALUES
(1, 'admin', 'admin@localhost', '5d724bb21756f212d097aecba32ae260b6cbe440', 'admin', 1),
(2, 'user', 'user@email.com', '9d4e1e23bd5b727046a9e3b4b7db57bd8d6ee684', 'user', 1),
(3, 'sabrina', '', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'user', 1),
(4, 'dan', '', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'user', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `allocation`
--
ALTER TABLE `allocation`
  ADD PRIMARY KEY (`allocation_id`),
  ADD KEY `ix_cheque` (`cheque`);

--
-- Indexes for table `banks`
--
ALTER TABLE `banks`
  ADD PRIMARY KEY (`bank_id`);

--
-- Indexes for table `cheques`
--
ALTER TABLE `cheques`
  ADD PRIMARY KEY (`cheque_id`),
  ADD KEY `ix_created_by` (`created_by`);

--
-- Indexes for table `cheque_print`
--
ALTER TABLE `cheque_print`
  ADD PRIMARY KEY (`print_id`),
  ADD KEY `ix_cheque` (`cheque`),
  ADD KEY `ix_bank` (`bank`);

--
-- Indexes for table `templates`
--
ALTER TABLE `templates`
  ADD PRIMARY KEY (`template_id`),
  ADD KEY `ix_bank` (`bank`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `allocation`
--
ALTER TABLE `allocation`
  MODIFY `allocation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `banks`
--
ALTER TABLE `banks`
  MODIFY `bank_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `cheques`
--
ALTER TABLE `cheques`
  MODIFY `cheque_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `cheque_print`
--
ALTER TABLE `cheque_print`
  MODIFY `print_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `templates`
--
ALTER TABLE `templates`
  MODIFY `template_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;
