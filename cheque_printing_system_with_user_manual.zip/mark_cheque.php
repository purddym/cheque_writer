<?php
include 'connect.php';
$bank_id = $_GET['bank'];
$cheque_id = $_GET['cheque'];
//do not do this until print button is clicked
//record as printed cheque
$chk = mysqli_query($conn,"select * from cheque_print where cheque=$cheque_id and bank=$bank_id");
if(mysqli_num_rows($chk)==0)//not printed yet so insert new
	$ins = mysqli_query($conn,"insert into cheque_print set cheque=$cheque_id, bank=$bank_id");
else
{
	$i = mysqli_fetch_array($chk);
	$id = $i['print_id'];
	$upd = mysqli_query($conn,"update cheque_print set no=no+1 where print_id=$id");
}
$updCheque = mysqli_query($conn,"update cheques set print_status=1 where cheque_id=$cheque_id");
header("location: ".$_SERVER['HTTP_REFERER']);
?>