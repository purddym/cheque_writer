<?php
include 'connect.php';
if(isset($_SERVER['HTTP_REFERER']) && isset($_GET['id']))
{
	$id = $_GET['id'];
	$del = mysqli_query($conn,"update cheque_print set cheque_num=Null where cheque=$id");
	header('location: '.$_SERVER['HTTP_REFERER']);
}
else
	header('location: ./');
?>