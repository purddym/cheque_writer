<?php
	if(isset($_POST['writeCheque']))
	{
		$payee = verify($_POST['payee']);
		$amount = verify($_POST['amount']);
		$reason = verify($_POST['reason']);
		$currency = verify($_POST['currency']);
		$token = verify($_POST['token']);
		//$amt_in_words = verify($_POST['amount_in_words']);
		require_once './Num2TextEnglish.php';
		$objNum2TextEng = new Num2TextEng();
		$amt_in_words = $objNum2TextEng->convertNumber($amount);
		$amt_in_words = ucfirst($amt_in_words);
		$cheque_date = verify($_POST['cheque_date']);
		//$created_by = 1;
		$chk = mysqli_query($conn,"select * from cheques where
		payee='$payee' and amount='$amount' and amount='$reason' and cheque_date='$cheque_date'");
		if(mysqli_num_rows($chk)==0)
		{
			//insert new cheque
			$ins = mysqli_query($conn,"insert into cheques set 
			payee='$payee', currency='$currency', amount='$amount', amt_in_words='$amt_in_words', reason='$reason', 
			cheque_date='$cheque_date', created_by=$user, created_on=now()");
			if($ins)
			{
				$cheque_id = mysqli_insert_id($conn);
				$upd = mysqli_query($conn,"update allocation set cheque=$cheque_id where token='$token'");
				$msg = 'New cheque has been created and is now ready for printing';
			}
			else
				$msg = 'A problem occurred while creating the cheque.<br><em>'.mysqli_error($conn).'</em>';
		}
		else
			echo 'Cheque already created!';
	}
	if(isset($_POST['editCheque']))
	{
		$payee = verify($_POST['payee']);
		$amount = verify($_POST['amount']);
		$reason = verify($_POST['reason']);
		$currency = verify($_POST['currency']);
		$token = verify($_POST['token']);
		$cheque_id = verify($_POST['id']);
		//$amt_in_words = verify($_POST['amount_in_words']);
		require_once './Num2TextEnglish.php';
		$objNum2TextEng = new Num2TextEng();
		$amt_in_words = $objNum2TextEng->convertNumber($amount);
		$amt_in_words = ucfirst($amt_in_words);
		$cheque_date = verify($_POST['cheque_date']);
		//$created_by = 1;
		//edit cheque
		$upd = mysqli_query($conn,"update cheques set 
		payee='$payee', currency='$currency', amount='$amount', 
		amt_in_words='$amt_in_words', reason='$reason', 
		cheque_date='$cheque_date', created_by=$user, created_on=now()
		where cheque_id=$cheque_id");
		if($upd)
		{
			$upd = mysqli_query($conn,"update allocation set cheque=$cheque_id where token='$token'");
			$msg = 'Cheque has been modified';
		}
		else
			$msg = 'A problem occurred while creating the cheque.<br><em>'.mysqli_error($conn).'</em>';
	}
?>