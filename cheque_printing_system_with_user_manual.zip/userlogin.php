<?php
include 'connect.php';
include 'fxns.php';
$username = verify($_POST['username']);
$pass = sha1($_POST['passwd']);
$chk = mysqli_query($conn,"select * from users where username='$username' and password='$pass'");
if(mysqli_num_rows($chk)==0)
{
	header('location: ./?ERR#'.mysqli_num_rows($chk));
}
else
{
	$r=mysqli_fetch_array($chk);
	$id = $r['user_id'];
	$type = $r['usertype'];
	setcookie('utype',$type,time()+8400,'/');
	setcookie('logged_in_user',$id,time()+8400,'/');
	header('location: ./');
}
?>