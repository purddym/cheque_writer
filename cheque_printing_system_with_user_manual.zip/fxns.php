<?php
function verify($data)
{
	$data = str_replace("'","''",$data);
	$data = stripslashes($data);
	$data = strip_tags($data);
	return $data;
}
?>