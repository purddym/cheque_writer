<?php
setcookie('logged_in_user','',time()-10,'/');
setcookie('utype','',time()-10,'/');
header('location: ./');
?>