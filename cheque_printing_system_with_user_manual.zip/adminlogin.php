<?php
include 'connect.php';
include 'fxns.php';
$username = verify($_POST['username']);
$pass = sha1($_POST['passwd']);
$chk = mysqli_query($conn,"select * from users where username='$username' and password='$pass'");
if(mysqli_fetch_array($chk)==0)
{
	header('location: ./?ERR');
}
else
{
	setcookie('admin',time());
	header('location: ./');
}
?>