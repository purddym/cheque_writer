<?php
include 'connect.php';
$cheque = $_GET['id'];
if(! isset($_SERVER['HTTP_REFERER']) || ! isset($_GET['id']) || empty($_GET['id']))
	header("location: ./");
else
	$sql = mysqli_query($conn,"update printed_cheques set cheque_num='' where cheque=$cheque");
?>